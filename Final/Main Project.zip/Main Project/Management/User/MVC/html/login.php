<!Doctype html>
<html>
<head>
    <title>Login Page</title>
    <link rel="stylesheet" href="../css/login.css">
    
</head>


<body>

    



    <center>
        <fieldset>

            <legend>Welcome back, please login</legend>

            <h2>Login</h2>

            <table>
                <tr>
                    <td class="a">Email</td>
                </tr>
                <tr>
                    <td>
                        <input type="text" name="email" placeholder="Enter your email"><br><br>
                    </td>
                </tr>

                <tr>
                    <td class="b">Password</td>
                </tr>
                <tr>
                    <td>
                        <input type="password" name="password" placeholder="Enter your password"><br><br>
                    </td>
                </tr>
            </table>

            <center>
                <input type="submit" class="button" value="Login">
                <a href="register.php" class="button">Register</a>
            </center>

        </fieldset>
    </center>
</body>
</html>
