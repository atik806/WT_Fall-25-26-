<!DOCTYPE html>
<html>
<head>
    <title>Contact Us - Event Management System</title>
    
</head>

<body>
    <div class="a">
        <h2>Contact Us</h2>

        <div class="b">
            <p><strong>Event Management System</strong></p>
            <p><strong>Phone:</strong> +880 123 456 789</p>
            <p><strong>Email:</strong> info@eventms.com</p>
            <p><strong>Address:</strong> 123 Event Street, Dhaka, Bangladesh</p>
        </div>
        <a href="login.php">Get Started</a>

        
    </div>
</body>
</html>
