<!DOCTYPE html>
<html>
<head>
    <title>User Dashboard</title>
    <link rel="stylesheet" href="../css/userDashboard.css">
</head>
<body>

<div class="navbar">
    <center>
        <h2>Event Management System</h2>
    </center>
    
    <a href="login.php">Logout</a>
</div>

<div class="container">

    <div class="sidebar">
        <a href="#">Dashboard</a>
        <a href="#">View Events</a>
        <a href="#">My Bookings</a>
        <a href="#">Request Event</a>
        <a href="#">Profile</a>
    </div>

    

        
    

</div>

</body>
</html>
